export class CreateProductTypeDto {
    description: String;
}
