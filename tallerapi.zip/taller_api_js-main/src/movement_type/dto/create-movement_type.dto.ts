export class CreateMovementTypeDto {
    description: String;
}
